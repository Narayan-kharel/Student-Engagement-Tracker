<?php
include("connection.php");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {


    $id = $_GET['id'];
    $uid = $_GET['uid'];
    $message = $_GET['message'];
    $pid = $_GET['pid'];
    $fromid = $_GET['fromid'];
    $type = $_GET['type'];




    $InsertSQL =  "INSERT INTO notifications(id,uid,message,pid,fromid,type) VALUES('$id','$uid','$message','$pid','$fromid','$type')";
    // echo 'success2';
    if ($row = mysqli_query($link, $InsertSQL)) {

        echo "success";
    } else {
        echo "failure";
    }



    mysqli_close($conn);
}
