<?php
include("connection.php");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {


    $uid = $_GET['uid'];
    $score = $_GET['score'];
    $awards = $_GET['awards'];
    $aid = $_GET['aid'];




    $InsertSQL = "UPDATE activities SET participant='accepted' WHERE id='$rid'";
    // echo 'success2';
    if ($row = mysqli_query($link, $InsertSQL)) {
        $InsertSQL1 = "UPDATE activities SET participant='$part' WHERE id='$aid'";
        // echo 'success2';
        if ($row = mysqli_query($link, $InsertSQL1)) {

            echo "success";
        } else {
            echo "failure";
        }
    } else {
        echo "failure";
    }




    mysqli_close($conn);
}
