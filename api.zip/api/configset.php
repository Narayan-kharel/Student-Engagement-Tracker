<?php

include("connection.php");
// echo "Connected";
// Check connection
if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {
    if (mysqli_query($link, "DROP TABLE students")) {
        echo "students drop success<br>";
    } else
        echo "students drop failure<br>";

    $sql = "CREATE TABLE students(studId CHAR(20) NOT NULL UNIQUE, name CHAR(30) NOT NULL, points INT,awards CHAR(200), email CHAR(30) NOT NULL,password CHAR(30) NOT NULL,activities VARCHAR(1000),PRIMARY KEY (email))";
    if (mysqli_query($link, $sql)) {
        echo "students create success<br>";
    } else
        echo "students create failure<br>";

    $sql = "INSERT INTO students(studId,name,points,awards,email,password) VALUES('s100','test student',180,'awards1,awards2,awards3,awards4,awards5,awards6,awards7,awards8,awards9,awards10,awards11,awards12','test@user.com','test')";
    if (mysqli_query($link, $sql)) {
        echo "student data insert success<br>";
    } else
        echo "student data insert failure<br>";

    $sql = "INSERT INTO students(studId,name,points,awards,email,password) VALUES('s101','test student2',70,'awards2','test@user2.com','test')";
    if (mysqli_query($link, $sql)) {
        echo "student data insert success<br>";
    } else
        echo "student data insert failure<br>";
    $sql = "INSERT INTO students(studId,name,points,awards,email,password) VALUES('s102','test student3',100,'awards3','test@user3.com','test')";
    if (mysqli_query($link, $sql)) {
        echo "student data insert success<br>";
    } else
        echo "student data insert failure<br>";


    if (mysqli_query($link, "DROP TABLE staff")) {
        echo "staff table drop success<br>";
    } else
        echo "staff table drop failure<br>";
    $sql = "CREATE TABLE staff(staffId CHAR(20) NOT NULL UNIQUE, name CHAR(30) NOT NULL, points CHAR(10),awards CHAR(200), email CHAR(30) NOT NULL,password CHAR(30) NOT NULL,activities VARCHAR(1000),PRIMARY KEY (email))";
    if (mysqli_query($link, $sql)) {
        echo "staff create success<br>";
    } else
        echo "staff create failure<br>";

    $sql = "INSERT INTO staff(staffId,name,points,awards,email,password) VALUES('st100','test staff',180,'awards1','test@staff.com','test')";
    if (mysqli_query($link, $sql)) {
        echo "staff data insert success<br>";
    } else
        echo "staff data insert failure<br>";

    $sql = "INSERT INTO staff(staffId,name,points,awards,email,password) VALUES('st101','test staff2',180,'awards2','test@staff2.com','test')";
    if (mysqli_query($link, $sql)) {
        echo "staff data insert success<br>";
    } else
        echo "staff data insert failure<br>";

    if (mysqli_query($link, "DROP TABLE activities")) {
        echo "activities table drop success<br>";
    } else
        echo "activities table drop failure<br>";
    $sql = "CREATE TABLE activities(id CHAR(20) NOT NULL, name CHAR(30) NOT NULL, category CHAR(30) NOT NULL, slots CHAR(5) NOT NULL,supervisor CHAR(30),superid CHAR(30), venue CHAR(30) NOT NULL, date CHAR(20) NOT NULL,enddate CHAR(20) NOT NULL, awards CHAR(50) NOT NULL, regdate CHAR(20) NOT NULL,participant VARCHAR(1000) ,PRIMARY KEY (id))";
    if (mysqli_query($link, $sql)) {
        echo "activities create success<br>";
    } else
        echo "activities create failure<br>";
    $sql = "INSERT INTO activities(id,name,category,slots,supervisor,venue,date,enddate,awards,regdate) VALUES('T229','nametest','cate','23','supervisor','venue','1632965460','1632965477','awards','671781889')";
    if (mysqli_query($link, $sql)) {
        echo "activities create success<br>";
    } else
        echo "activities create failure<br>";


    if (mysqli_query($link, "DROP TABLE newregistrations")) {
        echo "registration table drop success<br>";
    } else
        echo "registration table drop failure<br>";
    $sql = "CREATE TABLE newregistrations(id CHAR(20) NOT NULL,actid CHAR(20) NOT NULL, actname CHAR(50) NOT NULL, venue CHAR(30) NOT NULL,date CHAR(20) NOT NULL,name CHAR(30), pid CHAR(20) NOT NULL,type CHAR(20) NOT NULL,status CHAR(20),startdate CHAR(20),enddate CHAR(20) ,PRIMARY KEY (id))";
    if (mysqli_query($link, $sql)) {
        echo "registration create success<br>";
    } else
        echo "registration create failure<br>";


    if (mysqli_query($link, "DROP TABLE notifications")) {
        echo "notification table drop success<br>";
    } else
        echo "notification table drop failure<br>";
    $sql = "CREATE TABLE notifications(id CHAR(20) NOT NULL,uid CHAR(20) NOT NULL, message CHAR(100) NOT NULL,pid CHAR(20),fromid CHAR(20), type CHAR(30) NOT NULL,PRIMARY KEY (id))";
    if (mysqli_query($link, $sql)) {
        echo "notification create success<br>";
    } else
        echo "notification create failure<br>";


    if (mysqli_query($link, "DROP TABLE participants")) {
        echo "participants table drop success<br>";
    } else
        echo "participants table drop failure<br>";
    $sql = "CREATE TABLE participants(actid CHAR(20) NOT NULL,uid CHAR(20) NOT NULL, uname CHAR(100) NOT NULL,upoints CHAR(20), uawards CHAR(100))";
    if (mysqli_query($link, $sql)) {
        echo "participants create success<br>";
    } else
        echo "participants create failure<br>";
}
