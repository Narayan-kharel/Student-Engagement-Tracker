<?php
include("connection.php");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {


    $id = $_GET['id'];
    $name = $_GET['name'];
    $email = $_GET['email'];
    $pass = $_GET['password'];
    $mode = $_GET['mode'];



    if ($mode == '1') {

        $InsertSQL = "INSERT INTO students(studId,name,points,email,password) VALUES('$id','$name',0,'$email','$pass')";
        // echo 'success2';
        if ($row = mysqli_query($link, $InsertSQL)) {

            echo "success";
        } else {
            echo "failure";
        }
    } else {
        $InsertSQL = "INSERT INTO staff(staffId,name,points,email,password) VALUES('$id','$name',0,'$email','$pass')";
        if ($row = mysqli_query($link, $InsertSQL)) {

            echo "success";
        } else {
            echo "failure";
        }
    }



    mysqli_close($conn);
}
