<?php
include("connection.php");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {
    // echo "Connected";
    if (isset($_GET['uid'])) {


        $uid = $_GET['uid'];

        $sql = "DELETE FROM notifications WHERE uid='$uid'";

        $result = mysqli_query($link, $sql);

        if ($result)
            echo 'success';
    } else {
        echo 'failure';
    }


    mysqli_close($link);
}
