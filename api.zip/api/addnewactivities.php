<?php
include("connection.php");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {


    $Aid = $_GET['id'];
    $name = $_GET['name'];
    $category = $_GET['category'];
    $slots = $_GET['slots'];
    $supervisor = $_GET['supervisor'];
    $superid = $_GET['superid'];
    $venue = $_GET['venue'];
    $date = $_GET['date'];
    $enddate = $_GET['enddate'];
    $awards = $_GET['awards'];
    $regdate = $_GET['regdate'];



    $InsertSQL = "INSERT INTO activities(id,name,category,slots,supervisor,superid,venue,date,enddate,awards,regdate) VALUES('$Aid','$name','$category','$slots','$supervisor','$superid','$venue','$date','$enddate','$awards','$regdate')";
    // echo 'success2';
    if ($row = mysqli_query($link, $InsertSQL)) {

        echo "success";
    } else {
        echo "failure";
    }



    mysqli_close($conn);
}
