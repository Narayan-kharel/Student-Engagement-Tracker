
<?php

include("connection.php");
// echo "Connected";
// Check connection
if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {
    if (isset($_GET['email']) && isset($_GET['password']) && isset($_GET['mode'])) {

        $email = $_GET['email'];
        $password = $_GET['password'];
        $mode = $_GET['mode'];
        if ($mode == 1) {
            $sql = "SELECT * FROM students WHERE email='$email' AND password='$password'";
            $result = mysqli_query($link, $sql);
            $r = $result->fetch_all(MYSQLI_ASSOC);
            $m = json_encode($r[0]);
            $k = json_decode($m);
            $data = $k->name;
            if ($data) {
                echo $m;
            } else
                echo "false";

            mysqli_close($link);
        } else if ($mode == 2) {
            $sql = "SELECT * FROM staff WHERE email='$email' AND password='$password'";
            $result = mysqli_query($link, $sql);
            $r = $result->fetch_all(MYSQLI_ASSOC);
            $m = json_encode($r[0]);
            $k = json_decode($m);
            $data = $k->name;
            if ($data) {
                echo $m;
            } else
                echo "false";

            mysqli_close($link);
        }
    }
}

?>