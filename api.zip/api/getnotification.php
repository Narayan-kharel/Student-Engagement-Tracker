<?php

include("connection.php");
// echo "Connected";
// Check connection
if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {

    $uid = $_GET['uid'];
    $sql = "SELECT * FROM notifications WHERE uid='$uid'";
    $result = mysqli_query($link, $sql);
    $row = $result->fetch_all(MYSQLI_ASSOC);

    $json = json_encode($row);

    echo $json;

    mysqli_close($link);
}
