<?php
include("connection.php");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {
    // echo "Connected";
    if (isset($_GET['id'])) {


        $id = $_GET['id'];

        $sql = "DELETE FROM notifications WHERE id='$id'";

        $result = mysqli_query($link, $sql);

        if ($result)
            echo 'success';
    } else {
        echo 'failure';
    }


    mysqli_close($link);
}
