<?php
include("connection.php");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {


    $id = $_GET['id'];
    $action = $_GET['action'];

    $uid = $_GET['uid'];
    $aid = $_GET['aid'];
    $name = $_GET['uname'];



    if ($action == 'accept') {

        $InsertSQL = "UPDATE newregistrations SET status='accepted' WHERE pid='$uid' AND actid='$aid'";
        // echo 'success2';
        if ($row = mysqli_query($link, $InsertSQL)) {
            $InsertSQL1 = "INSERT INTO participants (actid,uid, uname,upoints, uawards) VALUES('$aid','$uid',$name,'0','')";
            // echo 'success2';
            if ($row = mysqli_query($link, $InsertSQL1)) {

                echo "success";
            } else {
                echo "failure";
            }
        } else {
            echo "failure";
        }
    } else {
        $InsertSQL = "UPDATE newregistrations SET status='rejected' WHERE pid='$uid' AND actid='$aid'";
        if ($row = mysqli_query($link, $InsertSQL)) {

            echo "success";
        } else {
            echo "failure";
        }
    }



    mysqli_close($conn);
}
