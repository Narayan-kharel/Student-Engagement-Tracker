<?php
include("connection.php");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {


    $actid = $_GET['actid'];
    $uname = $_GET['uname'];
    $uid = $_GET['uid'];
    $upoints = $_GET['upoints'];
    $uawards = $_GET['uawards'];





    $InsertSQL = "INSERT INTO participants(actid,uid,uname,upoints,uawards) VALUES('$actid','$uid','$uname','$upoints','$uawards')";
    // echo 'success2';
    if ($row = mysqli_query($link, $InsertSQL)) {

        echo "success";
    } else {
        echo "failure";
    }




    mysqli_close($conn);
}
