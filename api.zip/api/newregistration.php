<?php
include("connection.php");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
} else {


    $id = $_GET['id'];
    $actname = $_GET['actname'];
    $actid = $_GET['actid'];
    $venue = $_GET['venue'];
    $date = $_GET['date'];
    $name = $_GET['name'];
    $pid = $_GET['pid'];
    $type = $_GET['type'];
    $startdate = $_GET['startdate'];
    $enddate = $_GET['enddate'];



    $InsertSQL = "INSERT INTO newregistrations(id,actid,actname,venue,date,name,pid,type,status,startdate,enddate) VALUES('$id','$actname','$actid','$venue','$date','$name','$pid','$type','requested','$startdate','$enddate')";
    // echo 'success2';
    if ($row = mysqli_query($link, $InsertSQL)) {

        echo "success";
    } else {
        echo "failure";
    }



    mysqli_close($conn);
}
