<?php

$servername = "localhost";
$username = "example_user";
$password = "password";
$dbname = "example_database";
$ip = "192.168.177.194";

$link = mysqli_connect($servername, $username, $password, $dbname);
